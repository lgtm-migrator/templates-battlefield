import React from 'react';

const HeadLine = ({ children }) => (
  <div>
    {children}
  </div>
);

export default HeadLine;
