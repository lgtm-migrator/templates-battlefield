import HeadLine from './Headline';

export default HeadLine;