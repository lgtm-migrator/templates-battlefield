export const config = {
  link1: 'https://hackernoon.com/signup?ref=noonifications.tech',
  link2: 'https://app.hackernoon.com/subscriptions?ref=noonifications.tech',
  link3: 'https://app.hackernoon.com/new?ref=noonifications.tech',
  link4: 'https://sponsor.hackernoon.com/brand-as-author?ref=noonifications.tech',
  link5: 'https://hackernoon.com/?ref=noonifications.tech',
};