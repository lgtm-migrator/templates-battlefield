import CtaList from './CtaList';

export default CtaList;