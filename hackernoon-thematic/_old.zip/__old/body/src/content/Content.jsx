import React from 'react';

const Content = () => (
  <div>
    content
  </div>
);

export default Content;
