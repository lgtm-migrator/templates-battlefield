import Content from './Content';

export default Content;
