import Table from './Table.jsx';

export default Table;
