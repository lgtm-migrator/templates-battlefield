import GetPublished from './GetPublished';

export default GetPublished;