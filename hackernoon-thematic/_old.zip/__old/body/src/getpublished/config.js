export const link1 = "https://hackernoon.com/signup";
export const link2 = "https://publish.hackernoon.com/";