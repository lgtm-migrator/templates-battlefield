import JoinUs from './JoinUs';

export default JoinUs;