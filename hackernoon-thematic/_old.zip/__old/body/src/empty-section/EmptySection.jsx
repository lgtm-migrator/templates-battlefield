import React from 'react';

const EmptySection = ({ children }) => (
  <div>
    {children}
  </div>
);

export default EmptySection;
