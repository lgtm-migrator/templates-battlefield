import EmptySection from './EmptySection';

export default EmptySection;
