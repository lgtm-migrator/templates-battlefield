module.exports = {
  stories: ['../src/**/*.stories.jsx'],
  addons: [
    {
      name: '@storybook/addon-essentials',
    },
  ],
};

