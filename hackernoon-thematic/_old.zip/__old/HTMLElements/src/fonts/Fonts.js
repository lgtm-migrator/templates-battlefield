import React from 'react';

const Fonts = () => (
  <link href="https://fonts.googleapis.com/css?family=Merriweather:400,400i,700,700i|Merriweather+Sans:400,400i,700,700i|Source+Sans+Pro:400,400i,700,700i" data-testid="fontsHrefTest" rel="stylesheet" />
);

export default Fonts;
