import Fonts from './Fonts';

export default Fonts;
