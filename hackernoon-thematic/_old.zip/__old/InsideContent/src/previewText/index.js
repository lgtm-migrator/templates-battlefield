import PreviewText from './PreviewText';

export default PreviewText;
