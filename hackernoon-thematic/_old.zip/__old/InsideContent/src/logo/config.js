const config = {
  link: 'https://www.hackernoon.com',
  imgLink: 'https://creative-images-upld.s3.amazonaws.com/creative/newsletters/logos/brand/hackernoon.png'
};

export default config;