import TableLeft from './tableLeft.jsx';

export default TableLeft;
