import Sponsor from './Sponsor';

export default Sponsor;
